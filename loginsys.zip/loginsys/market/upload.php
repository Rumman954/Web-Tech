<?php
// Database connection details
$servername = "localhost";
$username = "root"; // Default username for XAMPP
$password = "";     // Default password for XAMPP
$dbname = "product_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $productName = $_POST['productName'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $description =chk_input( $_POST['description']);

    // Handle image upload
    $targetDir = "uploads/"; // Folder to store uploaded images
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true); // Create the folder if it doesn't exist
    }
    $image = basename($_FILES["productImage"]["name"]);
    $targetFilePath = $targetDir . $image;
    move_uploaded_file($_FILES["productImage"]["tmp_name"], $targetFilePath);

    // Insert data into the database
    $sql = "INSERT INTO products (name, quantity, price, description, image)
            VALUES ('$productName', '$quantity', '$price', '$description', '$image')";

    if ($conn->query($sql) === TRUE) {
        // echo "Product uploaded successfully!";
        header("location: /loginsys/dashboard.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

function chk_input($data) {
    //$data = trim($data);
    // $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
// Close connection
$conn->close();
?>