<?php

$host = "localhost";
$user= "root";
$pwd = "";
$database = "resturantdb";

?>
