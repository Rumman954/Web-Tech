<?php

//adding DB Cred
include "connect.php";

//Using isset func to check value set or not
if(isset($_POST['signUp'])){
    $firstName = $_POST['Fbusiness_name'];
    $lastName = $_POST['Lbusiness_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $password = $_POST['password']; 
    $password = md5($password); //encrypt password hexadecimel

    $checkEmail = "SELECT * From sellers where email='$email'";
    $result=$conn->query($checkEmail);
    if($result->num_rows>0){
        echo "Email Address Already Exists !";
    }
    else{
        $insertQuery = "INSERT INTO sellers(firstName,lastName,userName,email,phoneNumber,address,password)
                        VALUES('$firstName','$lastName','$username','$email','$phone','$address','$password')";
            if($conn->query($insertQuery)==TRUE){
                $sellerName = $firstName . "  " . $lastName;
                session_start(); 
                $_SESSION['sellerInfo'] = $sellerName ; 
                header("location: success.php");
                
            }
            else{
                echo "Error:".$conn->error;
            }
    }
}


?> 




