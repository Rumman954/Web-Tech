<section class="ffooter">
		<footer class="page-footer">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Contact US</h5>
                <p class="grey-text text-lighten-4">123, Kuratoli, Kuril, Dhaka</p>
                <p class="grey-text text-lighten-4">Phone : +8801769696969</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Social Media Links</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="#!">Facebook</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Instagram</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Twitter</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Whatsapp</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2025 Copyright @ Resturant
            <a class="grey-text text-lighten-4 right" href="#!">Made in Bangladesh with <span><i class="tiny material-icons">favorite</i></span></a>
            </div>
          </div>
        </footer>
	</section>