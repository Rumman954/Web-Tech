<?php 
    session_start();
    $sellerName = $_SESSION['sellerInfo'] ?? 'Default message';
    //Use To Redirect Index Page If Client Try Access Directly
    if(empty($_SESSION['sellerInfo'])){
        header("location: index.php");
    }
    else{
        $sellerName = $_SESSION['sellerInfo'] ?? 'Default message';
        unset($_SESSION['sellerInfo']);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,400i,700,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/success.css">
    <title>Registration Success</title>
</head>
<body>
    <div class="card">
        <div style="border-radius:200px; height:200px; width:200px; background: #F8FAF5; margin:0 auto;">
            <i class="checkmark">✓</i>
        </div>
        <h1>Welcome <span class="sellerName"><?php echo $sellerName ?></span></h1> 
        <p>Your Seller Account Created Successfully !</p>
        <input type="button" value="Login" onclick="window.open('login.php', '_self')" />
    </div>

    <script>

    </script>
</body>
</html>

