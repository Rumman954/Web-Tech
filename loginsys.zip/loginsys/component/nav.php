<?php
    session_start();
    $dashboardUrl = '';
    if(isset($_SESSION['email'])){
        $email=$_SESSION['email'];
        $dashboardUrl = '../loginsys/dashboard.php';
    }
?>

<ul>

    <?php if(!empty($dashboardUrl)){ 
        echo '<li><a href="../loginsys/index.php">Home</a></li>';
        echo '<li><a href="'.$dashboardUrl.'">Dashboard</a></li>';
        echo '<li><a href="../loginsys/logout.php">Logout</a></li>';
    }
    else{
        echo '<li><a href="../loginsys/index.php">Home</a></li>';
        echo'<li><a href="../loginsys/login.php">Login</a></li>';
        echo '<li><a href="#"><button id="openModal">Seller Signup</button></a></li>';
    }
    ?>

</ul>
