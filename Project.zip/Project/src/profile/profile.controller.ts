// src/profile/profile.controller.ts
import { Controller, Get, Put, Body, Param } from '@nestjs/common';
import { ProfileService } from './profile.service';

@Controller('profile')
export class ProfileController {
  constructor(private profileService: ProfileService) {}

  @Get(':userId')
  getProfile(@Param('userId') userId: number) {
    return this.profileService.getProfile(userId);
  }

  @Put(':userId')
  updateProfile(@Param('userId') userId: number, @Body() data) {
    return this.profileService.updateProfile(userId, data);
  }
}