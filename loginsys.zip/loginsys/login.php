<?php
    //adding DB Cred
    include "connect.php";
    $invalid;
    $icon = '<i class="fa-solid fa-triangle-exclamation fa-lg"></i>';

    if(isset($_POST['signIn'])){
        $email=$_POST['EMail'];
        $password=$_POST['password'];
        $password=md5($password) ;
        
        $sql="SELECT * FROM sellers WHERE email='$email' and password='$password'";
        $result=$conn->query($sql);
        if($result->num_rows>0){
         session_start();
         $row=$result->fetch_assoc();
         $_SESSION['email']=$row['email'];
         header("Location: dashboard.php");
         exit();
        }
        else{
            $invalid = "Incorrect Email or Password";
            
        }
     
     }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"/>
    <link rel="stylesheet" href="css/login.css">
    <title>Login</title>
</head>
<body>
    <div class="formContain">
        <form name="RegForm" onsubmit="return validateForm()" onreset="resetErrors()" method="post" action="login.php">
            <h1>seller login</h1>
            <?php if(!empty($invalid)){echo '
            <p id="invalid" class="error-message error">'. $icon .' '.$invalid.'</p>'; }?>
                
            
            
                <p class="email">
                    <!-- <label for="email">E-mail:</label> -->
                    <i class="fa-solid fa-envelope fa-lg"></i>
                    <input type="text" id="email" name="EMail" placeholder="someone@example.com" />
                    
                    <span id="email-error" class="error-message"></span>
                </p>
                <p class="pass">
                    <!-- <label for="password">Password:</label> -->
                    <i class="fa-solid fa-lock fa-lg"></i>
                    <input type="password" id="password" name="password" placeholder="************"/>
                    <span class="toggle-password" id="togglePassword">👁️</span>
                    <span id="password-error" class="error-message"></span>
                </p>
                <p>
                    <input type="submit" value="Login" name="signIn" />
                    <input type="reset" value="Reset" name="Reset" />
                </p>
            </form>
    </div>

    <script src="javascript/signin_validate.js"></script>
    <script src="javascript/passicon.js"></script>
</body>
</html>
