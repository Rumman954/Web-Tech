<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/modal.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"/>
    <link rel="stylesheet" href="css/products.css">
    <title>Login Sys</title>

</head>
<body>
    <?php require "component/nav.php" ?>
    <?php include "products.php"; ?>
    <div id="modal" class="modal">
        <div class="modal-content">
            <span class="close" id="closeModal">&times;</span>
            <h2>Seller Registration</h2>
            <form name="RegForm" onsubmit="return validateForm()" onreset="resetErrors()" class="modal-form" method="post" action="signup.php"> <!--Call a function when a form is submitted-->
                <label for="business_name">First Name:<span id="Fbusiness_name-error" class="error-message"></span></label>
                <input type="text" id="Fbusiness_name" name="Fbusiness_name" >
                
                <label for="business_name">Last Name:<span id="Lbusiness_name-error" class="error-message"></span></label>
                <input type="text" id="Lbusiness_name" name="Lbusiness_name" >

                <label for="username">Username:<span id="username-error" class="error-message"></span></label>
                <input type="text" id="username" name="username" >
   
                <label for="email">Email:<span id="email-error" class="error-message"></span></label>
                <input type="email" id="email" name="email" >
                
                <label for="phone">Phone Number:<span id="phone-error" class="error-message"></span></label>
                <input type="tel" id="phone" name="phone" >
                
                <label for="address">Address:<span id="address-error" class="error-message"></span></label>
                <textarea id="address" name="address" ></textarea>
                
                <label for="Pass">Password:<span id="password-error" class="error-message"></span></label>
                <div class="passbox">
                    <input type="password" name="password" id="password" class="password-input" placeholder="Enter password">
                    <span class="toggle-password" id="togglePassword">👁️</span>
                    
                    
                </div>

                <input type="checkbox" id="terms" name="terms" >
                I agree to the <a href="#">Terms and conditions</a>
                <span id="terms-error" class="error-message"></span>
                <button type="submit" value="Send" name="signUp">Register</button>
                <button type="reset">Reset</button>
            </form>
        </div>
    </div>
    <script src="javascript/modal.js"></script>
    <script src="javascript/passicon.js"></script>
    <script src="javascript/signup_validate.js"></script>
</body>
</html>