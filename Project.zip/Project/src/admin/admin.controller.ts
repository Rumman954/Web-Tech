// src/admin/admin.controller.ts
import { Controller, Get } from '@nestjs/common';
import { UserService } from '../user/user.service';

@Controller('admin')
export class AdminController {
  constructor(private userService: UserService) {}

  @Get('users')
  getAllUsers() {
    return this.userService.findAll();
  }
}