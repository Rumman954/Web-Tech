// src/dashboard/dashboard.service.ts
import { Injectable } from '@nestjs/common';

@Injectable()
export class DashboardService {
  getStats() {
    return {
      totalPatients: 100,
      activeAppointments: 12,
      revenue: 5000,
    };
  }
}