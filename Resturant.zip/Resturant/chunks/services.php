<section class="fservices">
		<div class="row" style="padding-left: 50px; padding-right: 50px;">
			<div class="col s12 l4 center" style="padding: 50px 50px;">
				<i class="large material-icons" >local_dining</i>
				<h5 class="header" >Variety of Dishes</h5>
			</div>
			<div class="col s12 l4 center" style="padding: 50px 50px;">
				<i class="large material-icons" >local_shipping</i>
				<h5 class="header" >Free Delivery</h5>
			</div>
			<div class="col s12 l4 center" style="padding: 50px 50px;">
				<i class="large material-icons" >mood</i>
				<h5 class="header" >Excellent Quality</h5>
			</div>
		</div>
	</section>