// Signin From Validation Start
// Getting Pass Eye To Change Style
const passEye = document.getElementById("togglePassword");

function validateForm() {
    const email = document.getElementById("email").value;
    const pass = document.getElementById("password").value;

    const emailErr = document.getElementById("email-error");
    const passErr = document.getElementById("password-error");
    
    emailErr.textContent = "";
    passErr.textContent = "";


    let isValid = true;
    if (email === "" || !email.includes("@") || !email.includes(".")) {
        emailErr.textContent = "Please enter a valid email address.";
        isValid = false;
    }
    if (pass === "" || pass.length < 8) {
        passErr.textContent = "Please enter a password with at least 8 characters.";
        passEye.style.cssText = `
        position: absolute;
        top: 21%;
        right: 3%;
        transform: translateY(0);
      `;
        isValid = false;
    }
    if (isValid) {
        // alert("Form submitted successfully!");
        return true;
    } else {
        return false; 
    }
}

function resetErrors() {
    document.getElementById("email-error").textContent = "";
    document.getElementById("password-error").textContent = "";
    passEye.removeAttribute('style');
    document.getElementById("invalid").remove();
    
    // Reset PassEye to Default Style
//     passEye.style.cssText = `
//     position: absolute;
//     top: 21%;
//     right: 3%;
//     transform: translateY(0);
//   `;
    // passEye.style.removeProperty('position');
    

}
// Signin From Validation End
