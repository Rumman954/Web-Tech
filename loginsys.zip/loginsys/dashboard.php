<?php 
    session_start();
    include "connect.php";
    $Seller;
    if(isset($_SESSION['email'])){
        $email=$_SESSION['email'];
        $query=mysqli_query($conn, "SELECT sellers.* FROM `sellers` WHERE sellers.email='$email'");
        while($row=mysqli_fetch_array($query)){
            $Seller= $row['firstName'].' '.$row['lastName'];
        }
    }else{
        header("location: index.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/product_form.css">
    <title>WELCOME &nbsp| &nbsp<?php echo $Seller ?></title>
</head>
<body>
<ul>
    <li><a href="../loginsys/index.php">Home</a></li>
    <li><a href="../loginsys/logout.php">Logout</a></li>
</ul>
<?php 
    include "market/product_form.php";
?>
</body>
</html>