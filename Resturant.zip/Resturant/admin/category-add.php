<?php 
session_start(); // Required to use $_SESSION
require('layout/header.php'); 
require('layout/left-sidebar-long.php'); 
require('layout/topnav.php'); 
require('layout/left-sidebar-short.php'); 
?>

<div class="section white-text" style="background: #B35458;">

	<div class="section">
		<h3>Add Categories</h3>
	</div>

    <div class="section center" style="padding: 40px;">

        <form action="../backends/admin/cat-add.php" method="post">

            <?php if (isset($_SESSION['msg'])): ?>
                <div class="row" style="background: red; color: white;">
                    <div class="col s12">
                        <h6><?= $_SESSION['msg'] ?></h6>
                    </div>
                </div>
                <?php unset($_SESSION['msg']); ?>
            <?php endif; ?>

            <div class="row">
                <div class="col s6">
                    <div class="input-field">
                        <input id="name" name="name" type="text" class="validate" style="color: white; width: 70%;" required>
                        <label for="name" style="color: white;"><b>Category Name :</b></label>
                    </div>
                </div>
                <div class="col s6">
                    <div class="input-field">
                        <input id="short_desc" name="short_desc" type="text" class="validate" style="color: white; width: 70%;" required>
                        <label for="short_desc" style="color: white;"><b>Short Description :</b></label>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col s12">
                    <div class="input-field">
                        <input id="long_desc" name="long_desc" type="text" class="validate" style="color: white; width: 70%;" required>
                        <label for="long_desc" style="color: white;"><b>Long Description :</b></label>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col s12 right-align">
                    <a href="category-list.php" class="waves-effect waves-light btn red lighten-1">Dismiss</a>
                    <button type="submit" class="waves-effect waves-light btn green">Add New</button>
                </div>
            </div>

        </form>
    </div>
</div>

<?php 
require('layout/about-modal.php'); 
require('layout/footer.php'); 
?>
