<!-- <?php
// session_unset();
// session_destroy();
// header("location: index.php");

?> -->

<?php
    session_start();

    $helper = array_keys($_SESSION);
    foreach ($helper as $key){
        unset($_SESSION[$key]);
        header("location: index.php");
    }

    
?>
