<?php
// Database connection details
$servername = "localhost";
$username = "root"; // Default username for XAMPP
$password = "";     // Default password for XAMPP
$dbname = "product_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all products from the database
$sql = "SELECT * FROM products";
$result = $conn->query($sql);

// Close connection after fetching data
$conn->close();
?>


<div class="content">
    <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="wrapper">
                <div class="container">
                    <div class="top" style="background-image:url('market/uploads/<?php echo htmlspecialchars_decode($row['image']); ?>'); background-repeat:no-repeat; background-position: center center; width: 100%;
                        height: 80%;"></div>
                        <div class="bottom">
                            <div class="left">
                                <div class="details">
                                    <h1><?php echo htmlspecialchars_decode($row['name']); ?></h1>
                                    <p><strong>Quantity:</strong> <?php echo htmlspecialchars_decode($row['quantity']); ?></p>
                                    <p><i class="fa-solid fa-bangladeshi-taka-sign"></i>&nbsp<?php echo htmlspecialchars_decode($row['price']); ?></p>
                                </div>
                    
                            </div>
                        </div>
                    </div>
                    <div class="inside">
                        <div class="icon"><i class="fa-solid fa-circle-info fa-lg"></i></div>
                        <div class="contents">
                            <p><strong>Description:</strong> <?php echo htmlspecialchars_decode($row['description']); ?></p>
                        </div>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No products found.</p>
    <?php endif; ?>
</div>