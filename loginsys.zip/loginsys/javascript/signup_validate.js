function validateForm() {
    const Fbusiness_name = document.getElementById('Fbusiness_name').value;
    const Lbusiness_name = document.getElementById('Lbusiness_name').value;
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const address = document.getElementById('address').value;
    const password = document.getElementById('password').value;
    const terms = document.getElementById('terms').checked;

    const Fbusiness_nameErr = document.getElementById("Fbusiness_name-error");
    const Lbusiness_nameErr = document.getElementById("Lbusiness_name-error");
    const usernameErr = document.getElementById("username-error");
    const emailErr = document.getElementById("email-error");
    const phoneErr = document.getElementById("phone-error");
    const addressErr = document.getElementById("address-error");
    const passwordErr = document.getElementById("password-error");
    const termsErr = document.getElementById("terms-error");

    Fbusiness_nameErr.textContent = "";
    Lbusiness_nameErr.textContent = "";
    usernameErr.textContent = "";
    emailErr.textContent = "";
    phoneErr.textContent = "";
    addressErr.textContent = "";
    passwordErr.textContent = "";
    termsErr.textContent = "";

    let isValid = true;
    if (Fbusiness_name === "" || /\d/.test(Fbusiness_name)) {
        Fbusiness_nameErr.textContent = "Please enter your name properly.";
        isValid = false;
    }
    if (Lbusiness_name === "" || /\d/.test(Lbusiness_name)) {
        Lbusiness_nameErr.textContent = "Please enter your name properly.";
        isValid = false;
    }
    if (username === "") {
        usernameErr.textContent = "Username is Required";
        isValid = false;

    }
    if (email === "" || !email.includes("@") || !email.includes(".")) {
        emailErr.textContent = "Please enter a valid email address.";
        isValid = false;
    }
    if (phone === "") {
        phoneErr.textContent = "Phone number is Required";
        isValid = false;
    }
    if (address === "") {
        addressErr.textContent = "Please enter your address.";
        isValid = false;
    }
    if (password === "" || password.length < 8) {
        passwordErr.textContent = "Enter a password with at least 8 characters.";
        isValid = false;
    }
    if (!terms) {
        termsErr.textContent = "Check to agree Terms";
        isValid = false;
    }
    if (isValid) {
        // alert("Form submitted successfully!");
        return true;
    } else {
        return false; 
    }
}
function resetErrors() {
    document.getElementById("Fbusiness_name-error").textContent = "";
    document.getElementById("Lbusiness_name-error").textContent = "";
    document.getElementById("username-error").textContent = "";
    document.getElementById("email-error").textContent = "";
    document.getElementById("phone-error").textContent = "";
    document.getElementById("address-error").textContent = "";
    document.getElementById("password-error").textContent = "";
    document.getElementById("terms-error").textContent = "";
}